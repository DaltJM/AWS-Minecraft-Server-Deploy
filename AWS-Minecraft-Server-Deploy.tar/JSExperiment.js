//Alert box on page load
window.onload = function AlertBox() {
    alert("How did you get here!?");

}