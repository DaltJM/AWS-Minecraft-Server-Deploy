AWS Minecraft Server Deploy
